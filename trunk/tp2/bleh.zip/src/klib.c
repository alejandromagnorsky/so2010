/*
 * klib.c
 * General purpose source file for basic functionality needed by the kernel.
*/

#include "../include/klib.h"

void __idt__initEntry(idtentry_t entry, uint16 selector, uint32 offset) {

    entry->selector = selector;
    
    entry->offset_l = offset & 0xFFFF;
    entry->offset_h = offset >> 16;
    
    entry->type_attr = ACS_INT;
    entry->zero = 0;
    
    return;
}
