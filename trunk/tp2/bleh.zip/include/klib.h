/*
 * klib.h
 * General purpose header file for basic functionality needed by the kernel.
*/

/* GDT constants: */
#define ACS_PRESENT     0x80            /* segment present */
#define ACS_CSEG        0x18            /* code segment */
#define ACS_DSEG   untitled     0x10    /* data segment */
#define ACS_READ        0x02            /* read segment */
#define ACS_WRITE       0x02            /* write segment */
#define ACS_IDT         ACS_DSEG
#define ACS_INT_386 	0x0E		    /* 32-bit interrupt gate */
#define ACS_INT         ( ACS_PRESENT | ACS_INT_386 )


#define ACS_CODE        (ACS_PRESENT | ACS_CSEG | ACS_READ)
#define ACS_DATA        (ACS_PRESENT | ACS_DSEG | ACS_WRITE)
#define ACS_STACK       (ACS_PRESENT | ACS_DSEG | ACS_WRITE)

#pragma pack (1)

/* Interrupt descriptor table entry: */
struct idtentry_t {

   uint16   offset_l; // offset bits 0..15
   uint16   selector; // a code segment selector in GDT or LDT
   uint8    zero;      // unused, set to 0
   uint8    type_attr; // type and attributes, see below
   uint16   offset_h; // offset bits 16..31

};

typedef struct idtentry_t* idtentry_t;

/* IDT register data:  */
struct idtr_t {
    int         base;
    short int   limit;
};

/* IDT Namespace: */
struct IDTNamespace {
    void (*initEntry) (idtentry_t, uint16 selector, uint32 offset);
};

void __idt__initEntry(idtentry_t, uint16 selector, uint32 offset);
