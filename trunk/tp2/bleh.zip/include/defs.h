/*
 * defs.h
 * Handy definitions to make code simpler and more maintainable.
*/

#define TRUE    1
#define FALSE   0

#define bool    unsigned char
#define uint8   unsigned char
#define uint16  unsigned short int
#define uint32  unsigned int

#define forever for(;;)
#define skip    if(0)
