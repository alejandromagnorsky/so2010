#ifndef _CPUID_H_
#define _CPUID_H_

#include "io.h"
int detect_cpu(char*);

#endif
