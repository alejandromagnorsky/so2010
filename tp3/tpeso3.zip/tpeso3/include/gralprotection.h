int gralprotection(char * input);
